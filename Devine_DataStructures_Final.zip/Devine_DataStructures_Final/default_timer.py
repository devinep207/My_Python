import timeit
start_time = timeit.default_timer()
print("Hello World" *100)
end_time = timeit.default_timer()
print (end_time - start_time)
