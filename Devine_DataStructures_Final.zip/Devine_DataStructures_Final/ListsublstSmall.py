# Patrick devine
#Ed Cauthorn
#Data Structures
#11-3-19

Inputt = []

# list of length in which we have to split 
length_to_split = [209715, 209715, 209715, 209715, 209715] 
  
# Using islice 
Inputt = iter(Input) 
Output = [list(islice(Inputt, elem)) 
          for elem in length_to_split] 
  
# Printing Output 
print("Initial list is:", Input) 
print("Split length list: ", length_to_split) 
print("List after splitting", Output)

#print([Output[0]])

L1 = ([Output[0]])
L2 = ([Output[1]])
L3 = ([Output[2]])
L4 = ([Output[3]])
L5 = (Output)


with open('your_file1.txt', 'w') as f:
    for item in L1:
        f.write("%s\n" % item)

with open('your_file2.txt', 'w') as f:
    for item in L2:
        f.write("%s\n" % item)


with open('your_file3.txt', 'w') as f:
    for item in L3:
        f.write("%s\n" % item)


with open('your_file4.txt', 'w') as f:
    for item in L4:
        f.write("%s\n" % item)

with open('your_file5.txt', 'w') as f:
    for item in L5:
