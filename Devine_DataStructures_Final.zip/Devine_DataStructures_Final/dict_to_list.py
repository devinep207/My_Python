spam = {'color': 'red', 'age': 42}
spam.keys()

dict_keys(['color', 'age'])

list(spam.keys())

['color', 'age']
