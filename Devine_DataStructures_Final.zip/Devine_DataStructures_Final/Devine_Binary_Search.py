#Patrick Devine
#Ed Cauthorn
#DataStructures

from math import floor
import sys
from time import perf_counter


def binary_search(Array, Search_Term):
    n = len(Array)
    L = 0
    R = n-1
    
    while L <= R:
        mid = floor((L+R)/2)
        if Array[mid] < Search_Term:
            L = mid + 1
        elif Array[mid] > Search_Term:
            R = mid - 1
        else:
            return mid
    return -1


# Insert your array here
A = [1,2,3,4,7,9,12,14,18,19,22,23,26,28,32,34,55,77,87,99,]
# This linkedlist of values gives us one more way to access our target value
LinkiList = {'a':1,'b':2,'c':3,'d':4,'e':7,'f':9,'g':12,'h':14,'i':18,'j':19,'k':22,
             'l':23,'m':26,'n':28}
# term to be searched
term = 14
start=perf_counter()
index = binary_search(A, term)
elapsed = perf_counter()-start

if index >= 0:
    print("{} is at index {}".format(A[index], index))
    print(F"Done in {elapsed:8.3}");
else:
    print("Search term not found")
