import time
import os

 

start = time.time()
numbers = [2, 8, 1, 4, 6, 3, 7] 
numbers.sort()
print(numbers)

end = time.time()
print(end - start)
