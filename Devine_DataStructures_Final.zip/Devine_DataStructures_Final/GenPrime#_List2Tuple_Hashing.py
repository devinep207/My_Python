# Patrick Devine
#Ed Cauthorn
#Data Structures and algorithms
# October 20th 2019
# Hash Function


# first find all non primes
#then use list comprehension to locate primes
noprimes = set(j for i in range(2, 8) for j in range(i*2, 50, i))

primes = [x for x in range(2, 50) if x not in noprimes]

print('These are the primes upto 50:')
print(primes)



#lists are mutable and can't be hashed
#  so convert list into a tuple 
def convert(list): 
    return tuple(list)




#must save the newly converted tuple as new variable
# now we call the variable a string and the hash function does the work!!
mila = convert(primes)

print ("The tuple hash value for primes is: " + str(hash(mila))) 

Rogers= convert(noprimes)

print("The hash value for all non-primes to 50 is:"  + str(hash(Rogers)))
