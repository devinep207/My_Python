#Patrick Devine
#Ed Cauthorn
#Data Structures 



# Python code to demonstrate naive 
# method to compute gcd ( Euclidean algo ) 
  
  
def computeGCD(x, y): 
  
   while(y): 
       x, y = y, x % y 
  
   return x 
 
# prints 12 
print ("The gcd of desired numbers : ",end="") 
print (computeGCD(150,50)) 
print (computeGCD(1000,10))
